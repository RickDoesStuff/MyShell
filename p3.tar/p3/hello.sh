echo hello world
then echo this should run
else exit whoops
echo this should also run
echo hello world
then echo this should run
else exit whoops
then echo this should also run